# Running our counterstrike code:

Simply use key.txt on both the default client and our modified clients to bypass registration checking.
