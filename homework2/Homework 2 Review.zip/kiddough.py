#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re
import os
import sys
import string
from itertools import product
from argparse import ArgumentParser

char_substitutions = dict({
  'e' : ['3'],
  's' : ['$', '5'],
  'l' : ['1'],
  'i' : ['1'],
  't' : ['7'],
  'b' : ['8'],
  'a' : ['@','4'],
  'o' : ['0']
})

word_substitutions = dict({
  'acme'    : '^',
  'against' : 'v',
  'all'     : '*',
  'also'    : '&',
  'and'     : '&',
  'any'     : '*',
  'anything': '*',
  'at'      : '@',
  'back'    : '<',
  'bang'    : '!',
  'bar'     : '|',
  'bent'    : '~',
  'caution' : '!',
  'cost'    : '$',
  'cross'   : '+',
  'cross'   : 'x',
  'danger'  : '!',
  'dangers' : '!',
  'dollar'  : '$',
  'equal'   : '=',
  'equals'  : '=',
  'eye'     : 'i',
  'false'   : '!',
  'flat'    : '_',
  'floor'   : '_',
  'forth'   : '>',
  'forward' : '>',
  'from'    : '<',
  'grave'   : '`',
  'greater' : '>',
  'hash'    : '#',
  'if'      : '?',
  'in'      : '>',
  'inclined': '/',
  'into'    : '>',
  'is'      : '=',
  'knots'   : '&',
  'larger'  : '>',
  'left'    : '<',
  'like'    : '~',
  'line'    : '|',
  'money'   : '$',
  'mountain': '^',
  'next'    : '>',
  'none'    : '0',
  'not'     : '!',
  'number'  : '#',
  'once'    : '1',
  'or'      : '|',
  'pipe'    : '|',
  'riches'  : '$',
  'right'   : '>',
  'see'     : 'c',
  'star'    : '*',
  'superior': '>',
  'to'      : '2',
  'too'     : '2',
  'you'     : 'u'
})

#word_substitutions_multichar = dict({
#  'heart'   : '<3',
#  'implies' : '=>',
#  'numbers' : '#s',
#  'unequal' : '!=',
#})
#
#number_words_multichar = [
#  "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",
#  "sixteen", "seventeen", "eighteen", "nineteen"
#]
#
#tens_words = [
#  "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty",
#  "ninety"
#]
#
#for n, word in enumerate(number_words_multichar):
#  word_substitutions[word] = str(n)
#
#for n, word in enumerate(tens_words, 2):
#  word_substitutions[word] = str(n*10)

number_words = [
  "zero", "one", "two", "three", "four", "five", "six", "seven", "eight",
  "nine"
]

for n, word in enumerate(number_words):
  word_substitutions[word] = str(n)

def generate_mnemonic_passwords_for_line(words,
      case="mixed",
      do_char_substitutions=False,
      do_word_substitutions=False):
  # store character options for position/word in the input
  candidates = list()

  # iterate through each word and add possibile characters for that
  # word's position to 'candidates'
  for word in words:
    char = word[0]

    # keep different possibilities for this word in 'options'
    options = set()

    # upper and lower-case versions of initial character
    if case == "mixed" or case == "lower":
      options.add(char.lower())
    if case == "mixed" or case == "upper":
      options.add(char.upper())
    if case == "original":
      options.add(char)

    if do_char_substitutions:
      key = char.lower()

      # add character-to-character substitutions (e.g., l33tsp33k)
      if key in char_substitutions:
        subs = char_substitutions[key]
        # could be multiple possibilities for each char (see above)
        options.update(subs)

        # add upper-case versions of same
        options.update(map(string.upper, subs))

    if do_word_substitutions:
      key = word.lower()
      # add any word-to-character transformations
      # e.g., 'equals' -> '='; see list above
      if key in word_substitutions:
        options.add(word_substitutions[key])

    # append to candidate list at appropriate position
    candidates.append(options)

  # 'product' is a neat method from the built-in 'itertools' package
  # it's a generator which returns the cartesian product for the inputs
  # i.e., it generates all possible lists where position 0 is drawn from
  # the first input, position 1 is drawn from the second input, etc...
  # each input must be iterable
  # the *<list> notation means: expand this list into an argument list,
  # i.e., product(*c) => product(c[0], c[1], c[2], ...)
  for candidate in product(*candidates):
    candidate = ''.join(candidate) # turn candidates back into strings
    yield candidate

if __name__ == "__main__":
  parser = ArgumentParser(description="""A program to generate mnemonic passwords from text.""")
  parser.add_argument("-n", "--length", type=int, dest="length", default=8)
  parser.add_argument("--max-length", type=int, dest="min_length", default=8)
  parser.add_argument("--min-length", type=int, dest="max_length", default=16)

  parser.add_argument("--charset", type=str, dest="charset", default=string.letters + string.digits + string.punctuation)

  parser.add_argument("--case", type=str, choices=["upper", "lower", "mixed", "original"], default="mixed")

  parser.add_argument("-C", "--no-char-substitutions", action="store_false", dest="do_char_substitutions")
  parser.add_argument("-c", "--char-substitutions", action="store_true", dest="do_char_substitutions", default=True)

  parser.add_argument("-M", "--multi-char", action="store_true", dest="do_multichar_substitutions")

  parser.add_argument("-W", "--no-word-substitutions", action="store_false", dest="do_word_substitutions")
  parser.add_argument("-w", "--word-substitutions", action="store_true", dest="do_word_substitutions", default=True)

  parser.add_argument("input_filename", nargs="+")
  args = parser.parse_args()

  if args.do_multichar_substitutions:
    raise NotImplementedError

  if args.length is not None:
    args.min_length = args.length
    args.max_length = args.length

  for filename in args.input_filename:
    with open(filename) as f:
      # track already generated passwords so we don't output twice
      generated = set()

      for lineno, line in enumerate(f):
        line = line.strip()

        # split into array of words/numerals (but leave apostrophes for now)
        words = re.findall(r"[a-zA-Z0-9']+", line)

        # remove apostrophes
        words = map(lambda s: s.translate(None, "'"), words)

        # skip lines with fewer than N words
        # also skips blank lines
        if len(words) < args.min_length:
          continue

        # truncate long lines
        words = words[:args.max_length]

        print >>sys.stderr, "{:s}:{:3d} {:s}".format(os.path.basename(filename), lineno, ' '.join(words))
        for password in generate_mnemonic_passwords_for_line(words,
                case=args.case,
                do_char_substitutions=args.do_char_substitutions,
                do_word_substitutions=args.do_word_substitutions):
          print >>sys.stderr, password
          if password not in generated:
            print password
            generated.add(password)
