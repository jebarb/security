#!/usr/bin/python

import subprocess
import sys

while True:
	line = sys.stdin.readline()
	if line == None:
		sys.exit(0)
	line = line.strip()
	p2 = subprocess.Popen("/playpen/fooPasswordKeeper", stdin=subprocess.PIPE, stdout=subprocess.PIPE, shell=True)
	data = p2.communicate(line)
	if p2.returncode == 0:
		print "Password matched: " + line
		sys.exit(0)
