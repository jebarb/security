#!/bin/bash
while read guess
do
  echo $guess | /playpen/fooPasswordKeeper > /dev/null
  exitStatus=$?
  if [ $exitStatus -eq 0 ]
  then
    echo "Password cracked: '$guess'"
    exit 0
  fi
done
