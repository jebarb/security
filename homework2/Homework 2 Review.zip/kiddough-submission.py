#!/usr/bin/python

import re
import sys
import math
import string
import random
import hashlib

def hash(string):
	return hashlib.sha1(string).hexdigest()

def producePasswordsRecursive(string):
        mappings = {'o': ['0', '|', '1'], 'l': ['1'], 'e': ['3'], 'a': ['@', '4', '&'], 't': ['7', '2'], 'b': ['8'], 'i': ['1'], 's': ['$', '5', 'c'], 'w': ['?', 'y'], 'n': ['!'], 'f': ['4'], 'y': ['u']}
	if len(string) == 1:
		guesses = [];
		guesses.append(string[0])
		guesses.append(string[0].upper())
		if string[0] in mappings:
			for sub in mappings[string[0]]:
				guesses.append(sub)
		return guesses
	else:
		sub_guesses = producePasswordsRecursive(string[1:len(string)])
		guesses = []
		for sub_guess in sub_guesses:
			guesses.append(string[0] + sub_guess)
			guesses.append(string[0].upper() + sub_guess)
			if string[0] in mappings:
				sub_chars = mappings[string[0]]
				for sub in sub_chars:
					guesses.append(sub + sub_guess)
		return guesses

if(len(sys.argv) < 2):
	print("Argument error: must supply file to read from ie: 'python kiddough.py <file>'")
	sys.exit()
try:
	f = open(sys.argv[1],'r')
	for line in f:
		replace_punctuation = string.maketrans(string.punctuation, ' '*len(string.punctuation))
		line = line.translate(replace_punctuation)
		line = line.lower()
	        words = line.split()
        	if(len(words) < 8):
                	continue
	        password = ''
	        wordnum = 0
	        while wordnum < 8:
	                password += words[wordnum][0]
	                wordnum = wordnum + 1
		recursiveGuesses = producePasswordsRecursive(password)
		for guess in recursiveGuesses:
			print hash(guess)
	                
except IOError:
	print("Could not open file " + sys.argv[1])
